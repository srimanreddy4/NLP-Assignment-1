import pandas as pd
import krippendorff


df = pd.read_csv("human_eval.csv")
df = df[["20110065","21110050","22250041"]]
df = df.replace(["negative","neutral","positive"],[0,1,2])

data = df.to_numpy().T

alpha = krippendorff.alpha(reliability_data=data, level_of_measurement="nominal")
print("Krippendorff's alpha: {:.3f}".format(alpha))
